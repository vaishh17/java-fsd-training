/* Write a program to implement nested try-catch block for NULL Pointer exception
and NumberFormat Exception*/



package com.ust;

import java.util.Scanner;

class Blocks {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a character");
		String str=null;
		try {
			try {
				System.out.println(str.length());
			}catch(Exception e)
			{
				System.out.println("Null Pointer Exception");
				System.out.println(e);
			}
			try {
				int k=Integer.parseInt(str);
			}catch(Exception e)
			{
				System.out.println("Number Format Exception");
				System.out.println(e);
			}
		}catch(Exception e)
		{
			System.out.println("Exception");
		}
	}
}