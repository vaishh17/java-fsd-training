/*A student will not be allowed to sit in exam if his/her attendance is less than 75%.
Take following input from user
 
Number of classes held
Number of classes attended.
And print
percentage of class attended
Is student is allowed to sit in exam or not.*/



package com.ust;

import java.util.Scanner;
class StudentAttendance
{
public static void main(String args[])
{
 Scanner sc=new Scanner(System.in);
 System.out.println("no of classes held");
 int x=sc.nextInt();
 System.out.println("no of classes attend");
 int y=sc.nextInt();
 float total;
 total=((y*x)/100);
 if(total>=75) {
System.out.println("eligible");
}
else {
System.out.println(" not eligible");
}
}
}
