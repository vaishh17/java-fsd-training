package com.ust;

import java.util.Scanner;
class Employee
{
	public static void main(String[] args)
	{
		System.out.println("Enter the name of Employee: ");
		Scanner sc=new Scanner(System.in);
		String name=sc.next();
		System.out.println("Enter the Salary of Employee: ");
		int salary=sc.nextInt();
		System.out.println("Enter the year of joining: ");
		int year=sc.nextInt();
		if((year<=2017) && (salary>30000))
				{
			if(year<=2012)
			{
				float bonus = ((40*salary/100));
				System.out.println("Bonus will be: " +bonus);
			}
			else
			{
			float bonus = ((22*salary/100));
			System.out.println("Bonus will be: " +bonus);
				}
				}
		if((year<=2017) && (salary<30000))
		{
			if(year<=2012)
			{
				float bonus = ((40*salary/100));
				System.out.println("Bonus will be: " +bonus);
			}
			else
			{
			float bonus = ((33*salary/100));
			System.out.println("Bonus will be: " +bonus);
				}
				}
			if((year>=2017) && (salary<30000))
		{
	float bonus = ((15*salary/100));
	System.out.println("Bonus will be: " +bonus);
		}
		if((year>=2017) && (salary>30000))
		{
	float bonus = ((10*salary/100));
	System.out.println("Bonus will be: " +bonus);
		}
	}
}