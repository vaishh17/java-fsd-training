/*Write a program that prompts the user to input a positive integer. It should then output a message indicating whether 
the number is a prime number.*/



package com.ust;

import java.util.Scanner;
class PrimeNumber
{
	public static void main(String[] args)
	{
		System.out.println("Enter a positive integer");
		Scanner n = new Scanner(System.in);
		int a= n.nextInt();
		int x;
		boolean isPrime=true;
		n.close();
		for(int i=2;i<=a/2;i++)
		{
			x=a%i;
			if(x==0) {
				isPrime=false;
				break;
			}
		}
			if(isPrime)
				System.out.println("Prime Number");
			else
				System.out.println("Not Prime Number");
	}
}