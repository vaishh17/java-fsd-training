package com.ust;

import java.util.Scanner;

class Occurence
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String: ");
		String str=sc.next();
		char[]ch=str.toCharArray();
		
		System.out.println("Enter the character whose occurence has to be counted: ");
		char n=sc.next().charAt(0);
		
		int count =0;
		for(int i=0;i<ch.length;i++)
		{
			if(ch[i]==n) {
				count++;
			}
		}
		System.out.println("Number of occurence of the character "+n+" is "+count);
	}
	
}
