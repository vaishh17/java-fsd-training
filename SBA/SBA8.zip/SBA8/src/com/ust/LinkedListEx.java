/*Implement LinkedList and add, remove, elements in the LinkedList and perform sorting of the 
elements using the iterator.*/


package com.ust;

import java.util.LinkedList;
import java.util.ListIterator;

public class LinkedListEx {
	public static void main(String[] args)
	{
		LinkedList<String>list=new LinkedList<String>();
		list.add("Red");
		list.add("Italy");
		list.add("Blue");
		list.add("London");
		list.add("Paris");
		list.add("Purple");
		
		System.out.println("Linkedlist: "+list);
		
		list.remove(5);
		System.out.println("Updated linked list: "+list);
		
		ListIterator list_iter=list.listIterator(2);
		System.out.println("The list is as follows: ");
		while(list_iter.hasNext()) {
			System.out.println(list_iter.next());
		}
	}

}
