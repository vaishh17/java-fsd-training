package com.demo.ust;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
public class Controller1 {
	
	
@GetMapping("/fault")
@HystrixCommand(fallbackMethod="fallbackDisplay")
	
	public void display() {
		System.out.println("in display");
		throw new RuntimeException("services down");
	}

public void fallbackDisplay() {
	System.out.println("in fallback method");
}

}
