package com.example.SpringBootClinic.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.SpringBootClinic.entity.Patient;

public interface PatientRepository extends MongoRepository<Patient, Long> {

}
